<?php 

$res=file_get_contents("http://127.0.0.1:8000/api/userprofile");
$arra=json_decode($res,true);
$downloadLink=$arra['qualification'];
echo  $downloadLink;

?>
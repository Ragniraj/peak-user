<?php 
session_start();
$username=$_SESSION['USERNAME'];
$name=$_SESSION['NAME'];
$id=$_SESSION['ID']; 

$servername = "localhost";
$username = "peaked";
$password = "Niraj@123";
$dbname = "peekinvesrt";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


 $sqli = "SELECT *FROM deposite";
$result = $conn->query($sqli);
while($rows = $result->fetch_assoc()) {
    if($rows['payment_status']=='finished'){
 $user_id=$rows['user_id'];
$amount=$rows['pay_amount'];
$bonus= $amount*(0.08);
  $sqlisert = "INSERT INTO bonus (user_id, bonus_amount) VALUES ('$user_id', '$bonus')";

 $conn->query($sqlisert);
    }
}




                                       
                                            










?>
<?php 

$servername = "localhost";
$username = "peaked";
$password = "Niraj@123";
$dbname = "peekinvesrt";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$permitted_chars = '012789abcdefghijkl';
$input=$permitted_chars;
    $input_length = strlen( $input);
    $random_string = '';
    for($i = 0; $i < $input_length; $i++) {
        $random_character = $input[mt_rand(0, $input_length - 1)];
        $random_string .= $random_character;
    }

$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$username=$_POST['username'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$referral=$_POST['referral'];
$password=$_POST['password'];
$refcode=$random_string;
$sql = "INSERT INTO user (first_name, last_name, username,email,phone,referral,passwords,refcode,status)
VALUES ('$firstname', '$lastname', '$username','$email','$phone','$referral','$password','$refcode','unblock')";

if ($conn->query($sql) === TRUE) {
  header('location:signin.php');
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}



?>
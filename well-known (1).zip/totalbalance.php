<?php 
session_start();
$username=$_SESSION['USERNAME'];
$name=$_SESSION['NAME'];
$id=$_SESSION['ID']; 

$servername = "localhost";
$username = "peaked";
$password = "Niraj@123";
$dbname = "peekinvesrt";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$total=0;
$sql = "SELECT *FROM deposite WHERE user_id='$id'";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
 if($row['payment_status']=='finished'){
   $total=$total+$row['pay_amount'];
 }
}
echo   $total;
?>
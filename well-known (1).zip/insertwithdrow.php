
<?php
session_start();
$id=$_SESSION['ID'];
$amount=$_POST['amount'];
$address=$_POST['pay_address'];
//URL, Where the JSON data is going to be sent
// sending post request to reqres.in
$url = "https://api.nowpayments.io/v1/payout";
$key = "X-API-Key:WRFPHA5-S6X4KBH-HFW5W0R-2PC57F4";

//initialize CURL
$ch = curl_init();

//token
$data = array(

	"email"=> "goodlucklogolucky@gmail.com",
    "password"=> "Mynewpass@@1" 
	);
$new_data = json_encode($data);

//options for curl
$array_options = array(
	
	//set the url option
	CURLOPT_URL=>'https://api.nowpayments.io/v1/auth',
	
	//switches the request type from get to post
	CURLOPT_POST=>true,
	
	//attach the encoded string in the post field using CURLOPT_POSTFIELDS
	CURLOPT_POSTFIELDS=>$new_data,
	
	//setting curl option RETURNTRANSFER to true
	//so that it returns the the response
	//instead of outputting it
	CURLOPT_RETURNTRANSFER=>true,
	
	//Using the CURLOPT_HTTPHEADER set the Content-Type to application/json
	CURLOPT_HTTPHEADER=>array($key,"Content-Type:application/json","Accept:application/json")
);

//setting multiple options using curl_setopt_array
curl_setopt_array($ch,$array_options);

// using curl_exec() is used to execute the POST request
$resp = curl_exec($ch);

	//decode the response
	$final_decoded_data = json_decode($resp,true);
	
	
    $token=$final_decoded_data['token']; 
	$token;
    



















//setup json data and using json_encode() encode it into JSON string





$data = array(

    "address"=>$address,
    "currency"=> "USDTTRC20",
    "amount"=> $amount,
    "ipn_callback_url"=>"https://nowpayments.io"
	);
$new_data = json_encode($data);

//options for curl
$array_options = array(
	
	//set the url option
	CURLOPT_URL=>$url,
	
	//switches the request type from get to post
	CURLOPT_POST=>true,
	
	//attach the encoded string in the post field using CURLOPT_POSTFIELDS
	CURLOPT_POSTFIELDS=>$new_data,
	
	//setting curl option RETURNTRANSFER to true
	//so that it returns the the response
	//instead of outputting it
	CURLOPT_RETURNTRANSFER=>true,
	
	//Using the CURLOPT_HTTPHEADER set the Content-Type to application/json
	CURLOPT_HTTPHEADER=>array($key,"Content-Type:application/json","Access-Control-Allow-Origin: https://nowpayments.io","Accept:application/json","Authorization:Bearer $token")
);

//setting multiple options using curl_setopt_array
curl_setopt_array($ch,$array_options);

// using curl_exec() is used to execute the POST request
$resp = curl_exec($ch);

	//decode the response
	$final_decoded_data = json_decode($resp,true);
	print_r($final_decoded_data);

	if(isset($final_decoded_data['success'])){
	
    $data=$final_decoded_data['address']; 
	}




//insert data
$servername = "localhost";
$username = "peaked";
$password = "Niraj@123";
$dbname = "peekinvesrt";

 $user_id=$id; 
$payment_id=$final_decoded_data['address'];
$payment_status=$final_decoded_data['amount'];
$pay_address=$final_decoded_data['pay_address'];
$price_amount=$final_decoded_data['status'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


$sql = "INSERT INTO withdrow(user_id, address, amount, batchWithdrawalId, status) 
VALUES ('$id',
'$pay_address',
'$price_amount',
'$payment_id',
'$payment_status'

)";

if ($conn->query($sql) === TRUE) {
    echo $data;
//	header('location:withdrow.php?success=withdrow submited sucessfully');
 
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}




curl_close($ch);



?>

<?php
session_start();
$servername = "localhost";
$username = "peaked";
$password = "Niraj@123";
$dbname = "peekinvesrt";
$conn = mysqli_connect($servername,$username, $password,$dbname);

if (!$conn) {

    echo "Connection failed!";

}

$username=$_POST['username'];
$password=$_POST['password'];

$sql="SELECT *FROM user WHERE username='$username'";
$result=mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
if($row['status']=='block'){
 header("Location:signin.php?status=Account is blocked");   
}
else{
if ($row['username'] === $username && $row['passwords'] === $password) {

    $_SESSION['USERNAME'] = $row['username'];

    $_SESSION['NAME'] = $row['first_name'];

    $_SESSION['ID'] = $row['id'];

$_SESSION['REFC'] = $row['refcode'];
    header("Location:index.php?success=Successfully Login");

    exit();

}else{

    header("Location:signin.php?error=Incorect User name or Password ");

    exit();

}
}

?>

<?php


session_start();
$username=$_SESSION['USERNAME'];
$name=$_SESSION['NAME']; 
$id=$_SESSION['ID'];

$order_id=$username.$id;


$amount=$_POST['amount'];
//URL, Where the JSON data is going to be sent
// sending post request to reqres.in
$url = "https://api.nowpayments.io/v1/payment";
$key = "X-API-Key:WRFPHA5-S6X4KBH-HFW5W0R-2PC57F4";

//initialize CURL
$ch = curl_init();

//setup json data and using json_encode() encode it into JSON string
$data = array(
	"price_amount"=>$amount,
  "price_currency"=>"USDTTRC20",
  "pay_currency"=>"USDTTRC20",
  "ipn_callback_url"=> "https://nowpayments.io",
  "order_id"=>$order_id,
  "order_description"=>"Apple Macbook Pro 2019 x 1",
  "is_fixed_rate"=>true,
  "is_fee_paid_by_user"=>false
	);
$new_data = json_encode($data);

//options for curl
$array_options = array(
	
	//set the url option
	CURLOPT_URL=>$url,
	
	//switches the request type from get to post
	CURLOPT_POST=>true,
	
	//attach the encoded string in the post field using CURLOPT_POSTFIELDS
	CURLOPT_POSTFIELDS=>$new_data,
	
	//setting curl option RETURNTRANSFER to true
	//so that it returns the the response
	//instead of outputting it
	CURLOPT_RETURNTRANSFER=>true,
	
	//Using the CURLOPT_HTTPHEADER set the Content-Type to application/json
	CURLOPT_HTTPHEADER=>array($key,"Content-Type:application/json","Accept:application/json")
);

//setting multiple options using curl_setopt_array
curl_setopt_array($ch,$array_options);

// using curl_exec() is used to execute the POST request
$resp = curl_exec($ch);

	//decode the response
	$final_decoded_data = json_decode($resp,true);
	$data=$final_decoded_data['pay_address']; 
	$_SESSION['PAY_ADDRESS']=$data;
	echo $data;

//close the cURL and load the page



//insert data
$servername = "localhost";
$username = "peaked";
$password = "Niraj@123";
$dbname = "peekinvesrt";


$payment_id=$final_decoded_data['payment_id'];
$payment_status=$final_decoded_data['payment_status'];
$pay_address=$final_decoded_data['pay_address'];
$price_amount=$final_decoded_data['pay_address'];
$price_currency=$final_decoded_data['price_currency'];
$pay_amount=$final_decoded_data['pay_amount'];
$amount_received=$final_decoded_data['amount_received'];
$order_id=$final_decoded_data['order_id'];
$is_fee_paid_by_user=$final_decoded_data['is_fee_paid_by_user'];


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


$sql = "INSERT INTO deposite(user_id, payment_id, payment_status, pay_address, price_amount, price_currency, pay_amount, amount_received, order_id, is_fee_paid_by_user) 
VALUES ('$id',
'$payment_id',
'$payment_status',
'$pay_address',
'$price_amount',
'$price_currency',
'$pay_amount',
'$amount_received',
'$order_id',
'$is_fee_paid_by_user')";

if ($conn->query($sql) === TRUE) {
	echo $final_decoded_data['pay_address'];
	header('location:addressofdeposite.php');
 
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}




curl_close($ch);



?>

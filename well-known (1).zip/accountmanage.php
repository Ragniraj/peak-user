<?php
session_start();
$username=$_SESSION['USERNAME'];
$name=$_SESSION['NAME'];
if($username<0){
    header('location:signin.php');
}


$servername = "localhost";
$username = "peaked";
$password = "Niraj@123";
$dbname = "peekinvesrt";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


// Create connection


                                       
                                            $sql = "UPDATE deposite SET payment_status='success' WHERE user_id=2";

                                            if ($conn->query($sql) === TRUE) {
                                              echo "Record updated successfully";
                                            } else {
                                              echo "Error updating record: " . $conn->error;
                                            }
                                        
                                              







?>
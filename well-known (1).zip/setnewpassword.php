<?php
session_start();
$servername = "localhost";
$username = "peaked";
$password = "Niraj@123";
$dbname = "peekinvesrt";
$conn = mysqli_connect($servername,$username, $password,$dbname);

if (!$conn) {

    echo "Connection failed!";

}

$email=$_POST['email'];
$password=$_POST['password'];

echo $username;
echo $password;

$sql="SELECT *FROM user WHERE email='$email'";
$result=mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

if ($row['email'] === $email) {

   $sqlup = "UPDATE user SET passwords='$password' WHERE email='$email'";
if ($conn->query($sqlup) === TRUE) {
  
  header("Location:index.php");
} else {
  echo "Error updating record: " . $conn->error;
}
 
}else{

    header("Location:signin.php?error=Incorect User name or password");

    exit();

}


?>
<?php
session_start();
$_SESSION['USERNAME']=false;
header('location:signin.php');


?>
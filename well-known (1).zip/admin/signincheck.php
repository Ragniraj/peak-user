<?php
session_start();
$servername = "localhost";
$username = "peaked";
$password = "Niraj@123";
$dbname = "peekinvesrt";
$conn = mysqli_connect($servername,$username, $password,$dbname);

if (!$conn) {

    echo "Connection failed!";

}

$username=$_POST['username'];
$password=$_POST['password'];

echo $username;
echo $password;

$sql="SELECT *FROM admin WHERE username='$username'";
$result=mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

if ($row['username'] === $username && $row['password'] === $password) {

    $_SESSION['ADMIN'] = $row['username'];


    $_SESSION['ID'] = $row['id'];

    header("Location:index.php?result=Login successfully");

    exit();

}else{

    header("Location:signin.php?error=Incorect User name or password");

    exit();

}


?>
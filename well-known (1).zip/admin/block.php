<?php
$servername = "localhost";
$username = "peaked";
$password = "Niraj@123";
$dbname = "peekinvesrt";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if(isset($_GET['user_id'])){
  $id=$_GET['user_id'];
$lock=true;
$sql = "UPDATE user SET status='block' WHERE id=$id";
if ($conn->query($sql) === TRUE) {
  echo '<script>alert("Record block successfully")</script>';
  header('location:index.php');
} else {
  echo "Error updating record: " . $conn->error;
}


}


?>
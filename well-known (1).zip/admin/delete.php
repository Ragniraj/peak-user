<?php 
$servername = "localhost";
$username = "peaked";
$password = "Niraj@123";
$dbname = "peekinvesrt";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
if(isset($_GET['ref_id'])){
    $user_id=$_GET['ref_id'];
		
 $sql = "DELETE FROM referral  WHERE id=$user_id";
 if ($conn->query($sql) === TRUE) {
  echo '<script>alert("Record deleted successfully")</script>';
  header('location:Deposite_history.php');
} else {
  echo "Error deleting record: " . $conn->error;
}
}
if(isset($_GET['user_id'])){
    $user_id=$_GET['user_id'];
		
 $sql = "DELETE FROM user  WHERE id=$user_id";
 if ($conn->query($sql) === TRUE) {
  echo '<script>alert("User deleted successfully")</script>';
  header('location:Deposite_history.php');
} else {
  echo "Error deleting record: " . $conn->error;
}
}
if(isset($_GET['payment_id'])){
    $payment_id=$_GET['payment_id'];
		
 $sql = "DELETE FROM deposite  WHERE payment_id=$payment_id";
 if ($conn->query($sql) === TRUE) {
  
  header('location:Deposite_history.php');
  echo '<script>alert("Record deleted successfully")</script>';
} else {
  echo "Error deleting record: " . $conn->error;
}

}


?>
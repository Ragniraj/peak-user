<?php
$servername = "localhost";
$username = "peaked";
$password = "Niraj@123";
$dbname = "peekinvesrt";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sqlup = "UPDATE actionwithdrow SET action='unblock' WHERE id=1";
if ($conn->query($sqlup) === TRUE) {
  header('location:withdrow_history.php?success=successfully blocked');
 
} else {
  echo "Error updating record: " . $conn->error;
}





?>
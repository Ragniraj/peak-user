<?php

$servername = "localhost";
$username = "peaked";
$password = "Niraj@123";
$dbname = "peekinvesrt";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$user_id=$_POST['user_id'];
$amount=$_POST['amount'];
$sql = "INSERT INTO balance (user_id,total_amount)
VALUES ('$user_id', '$amount')";

if ($conn->query($sql) === TRUE) {
  header('location:credit.php');
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}


?>